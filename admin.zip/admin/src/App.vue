<template>
  <div class="app-container">
    <!-- Left Sidebar -->
    <nav class="sidebar">
      <div class="logo">
        <img src="./assets/lms-logo.svg" alt="LMS Insights" class="logo-img" />
      </div>
      <div class="nav-items">
        <div class="nav-item active">
          <span class="nav-icon">⬜</span>
          Dashboard
        </div>
        <div class="nav-item">
          <span class="nav-icon">📊</span>
          Ressource Management
        </div>
        <div class="nav-item">
          <span class="nav-icon">⚙️</span>
          Settings
        </div>
        <div class="nav-item">
          <span class="nav-icon">❔</span>
          Help Center
        </div>
        <div class="nav-item">
          <span class="nav-icon">⚠️</span>
          Report a Problem
        </div>
      </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
      <!-- Top Header -->
      <header class="top-header">
        <div class="search-container">
          <input 
            type="text" 
            placeholder="Search something here"
            class="search-input"
          />
        </div>
        <div class="header-right">
          <span class="notification-icon">🔔</span>
          <span class="history-icon">↩️</span>
          <div class="user-avatar">👤</div>
        </div>
      </header>

      <!-- Dashboard Content -->
      <div class="dashboard">
        <div class="dashboard-header">
          <h1>Welcome Dan!</h1>
          <select class="period-select">
            <option>This month</option>
          </select>
        </div>

        <section class="engagement">
          <h2>Engagement</h2>
          <div class="chart-grid">
            <div class="chart-card">
              <div class="chart-header">
                <h3>Users in the last 30 days</h3>
                <span class="change negative">-5 % this month</span>
              </div>
              <UsersChart :data="usersData" />
            </div>

            <div class="chart-card">
              <h3>Popular times</h3>
              <PopularTimesChart :data="popularTimesData" />
            </div>
          </div>
        </section>

        <section class="resources">
          <div class="section-header">
            <h2>Resource Utilization & Content Popularity</h2>
            <select class="course-select">
              <option>All Courses</option>
              <option>Baumchirurg - Hauptkompetenzen</option>
              <option>Course 101</option>
              <option>Course 101 - Extension</option>
            </select>
          </div>

          <div class="stats-grid">
            <StatCard 
              title="Total Courses" 
              value="103" 
              change="+3"
              changeType="positive" 
            />
            <StatCard 
              title="Total Activities" 
              value="1,185" 
              change="+30"
              changeType="positive" 
            />
            <StatCard 
              title="Total Users" 
              value="1,203" 
              change="-65"
              changeType="negative" 
            />

          </div>

          <div class="chart-grid">
            <div class="chart-card">
              <h3>Top 5 Keywords</h3>
              <KeywordsList :keywords="topKeywords" />
            </div>
            <div class="chart-card">
              <h3>Search Trends</h3>
              <SearchTrendsChart :data="searchTrendsData" />
            </div>
          </div>
          
        </section>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import UsersChart from './components/UsersChart.vue'
import PopularTimesChart from './components/PopularTimesChart.vue'
import StatCard from './components/StatCard.vue'
import KeywordsList from './components/KeywordsList.vue'
import SearchTrendsChart from './components/SearchTrendsChart.vue'

const usersData = ref([
  { date: '2023-11-05', users: 280 },
  { date: '2023-11-15', users: 260 },
  { date: '2023-11-25', users: 250 },
  { date: '2023-12-05', users: 231 },
])

const popularTimesData = ref([
  { hour: '3', users: 50 },
  { hour: '6', users: 100 },
  { hour: '9', users: 200 },
  { hour: '12', users: 400 },
  { hour: '15', users: 350 },
  { hour: '18', users: 300 },
  { hour: '21', users: 150 },
  { hour: '24', users: 75 },
])

const topKeywords = ref([
  { name: 'Kompetenzen', count: 154, change: '+20' },
  { name: 'Grundlagen', count: 130, change: '+30' },
  { name: 'Gefahren', count: 115, change: '+25' },
  { name: 'Pflege', count: 80, change: '+5' },
  { name: 'Klettern', count: 74, change: '+5' },
])

const searchTrendsData = ref([
  { date: '5.11.', searches: 80 },
  { date: '12.11.', searches: 70 },
  { date: '19.11.', searches: 60 },
  { date: '26.11.', searches: 85 },
  { date: '3.12.', searches: 120 },
  { date: '10.12.', searches: 90 },
])
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.app-container {
  display: flex;
  min-height: 100vh;
  font-family: Arial, sans-serif;
}

.sidebar {
  width: 250px;
  background-color: white;
  padding: 20px;
  border-right: 1px solid #eee;
}

.logo {
  padding: 10px 0 20px;
}

.logo-img {
  height: 40px;
}

.nav-items {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px;
  border-radius: 4px;
  cursor: pointer;
  color: #666;
}

.nav-item:hover {
  background-color: #f5f5f5;
}

.nav-item.active {
  background-color: #f5f5f5;
  color: #333;
}

.main-content {
  flex: 1;
  background-color: #f5f5f5;
}

.top-header {
  background-color: #cc0000;
  padding: 15px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.search-container {
  flex: 1;
  max-width: 600px;
}

.search-input {
  width: 100%;
  padding: 8px 15px;
  border: none;
  border-radius: 4px;
  background-color: rgba(255, 255, 255, 0.1);
  color: white;
}

.search-input::placeholder {
  color: rgba(255, 255, 255, 0.7);
}

.header-right {
  display: flex;
  align-items: center;
  gap: 20px;
  color: white;
}

.user-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background-color: rgba(255, 255, 255, 0.1);
  display: flex;
  align-items: center;
  justify-content: center;
}

.dashboard {
  padding: 20px;
}

.dashboard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
}

h1 {
  font-size: 24px;
  font-weight: bold;
  color: #333;
}

h2 {
  font-size: 20px;
  margin-bottom: 20px;
  color: #333;
}

h3 {
  font-size: 16px;
  margin-bottom: 15px;
  color: #333;
}

.period-select, .course-select {
  padding: 8px 15px;
  border: 1px solid #ddd;
  border-radius: 4px;
  background-color: white;
}

.chart-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 30px;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 30px;
}

.chart-card {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.chart-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.change {
  font-size: 14px;
}

.change.positive {
  color: #22bb33;
}

.change.negative {
  color: #cc0000;
}

@media (max-width: 1200px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 768px) {
  .chart-grid {
    grid-template-columns: 1fr;
  }
  
  .stats-grid {
    grid-template-columns: 1fr;
  }
  
  .sidebar {
    width: 60px;
    padding: 10px;
  }
  
  .nav-item span:not(.nav-icon) {
    display: none;
  }
}
</style>